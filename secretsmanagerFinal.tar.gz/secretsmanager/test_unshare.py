from app import create_app
from app.models import db, ProjectShare

def test_unshare(share_id, current_user_id):
    app = create_app()
    
    with app.app_context():
        try:
            # Find the share
            share = ProjectShare.query.get(share_id)
            if not share:
                print(f"❌ Share {share_id} not found")
                return False
            
            print(f"📋 Share found: ID={share.id}, Project='{share.project.name}', Shared By={share.shared_by}, User={share.user_id}")
            
            # Check permissions
            if share.shared_by != current_user_id and share.project.owner_id != current_user_id:
                print(f"❌ Access denied. User {current_user_id} cannot remove this share")
                return False
            
            # Delete the share
            db.session.delete(share)
            db.session.commit()
            
            print(f"✅ Successfully removed share {share_id}")
            return True
            
        except Exception as e:
            print(f"❌ Error: {str(e)}")
            db.session.rollback()
            return False

if __name__ == '__main__':
    # Test with your share ID and user ID
    test_unshare(1, 1)  # share_id, current_user_id
